package mainPackage;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

public class AdminAddUser extends HttpServlet {

	/**
	 * Constructor of the object.
	 */
	public AdminAddUser() {
		super();
	}

	/**
	 * Destruction of the servlet. <br>
	 */
	public void destroy() {
		super.destroy(); // Just puts "destroy" string in log
		// Put your code here
	}



	public void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

try
{	    
     UserBean user = new UserBean();
     
     user.setUsername(request.getParameter("username"));
     user.setPassword(request.getParameter("password"));
     user.setFirstName(request.getParameter("FirstName"));
     user.setLastName(request.getParameter("LastName"));
     user.setEmail(request.getParameter("email"));
     user.setPhone(request.getParameter("phone"));

     user = UserDAO.AdminAddUser(user);
	   
     System.out.println ("creating new user");

    		 response.sendRedirect("/EricsStore/secured/ShowAll"); // Pre Login page 
    
     
} 
		
		
catch (Throwable theException) 	    
{
     System.out.println(theException); 
}
       }

}
