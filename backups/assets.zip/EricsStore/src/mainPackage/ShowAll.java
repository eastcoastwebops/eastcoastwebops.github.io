package mainPackage;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.Arrays;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class ShowAll extends HttpServlet {

	/**
	 * Constructor of the object.
	 */
	public ShowAll() {
		super();
	}

	/**
	 * Destruction of the servlet. <br>
	 */
	public void destroy() {
		super.destroy(); // Just puts "destroy" string in log
		// Put your code here
	}


	public void doPost(HttpServletRequest request, HttpServletResponse response) 
	           throws ServletException, java.io.IOException {

}
	
	public void doGet(HttpServletRequest request, HttpServletResponse response) 
	           throws ServletException, java.io.IOException {

try
{	    


List<UserBean> userList = UserDAO.showAll();
System.out.println(userList.size());
//System.out.println( Arrays.toString(userList.toArray() ) );

response.setContentType("text/html");
PrintWriter out = response.getWriter();

request.getRequestDispatcher("../header.jsp").include(request, response);

out.print("<h2>List of Current Users</h2>");
out.println("<table id=\"userlist\">");
out.println("<tr><th>User ID</th><th>First Name</th><th>Last Name</th><th>Username</th><th>Password</th><th>Email</th><th>Phone</th><th></th></tr>");

for(int i = 0; i < userList.size(); i++) {
out.println("<tr><td>");
out.print(userList.get(i).getUserID() + "</td><td>");
out.print(userList.get(i).getFirstName() + "</td><td>");
out.print(userList.get(i).getLastName()  + "</td><td>");
out.print(userList.get(i).getUsername()  + "</td><td>");
out.print(userList.get(i).getPassword()  + "</td><td>");
out.print(userList.get(i).getEmail()  + "</td><td>");
out.print(userList.get(i).getPhone()  + "</td><td>");
out.print("<a href=\"UpdateUserGet?username=" + userList.get(i).getUsername() + "&firstname="+userList.get(i).getFirstName()+"&lastname="+userList.get(i).getLastName()+"&password="+userList.get(i).getPassword()+"&email="+userList.get(i).getEmail()+"&phone="+userList.get(i).getPhone()+"\">EDIT</a></td>");
out.println("</tr>");
}

out.println("</table>");
out.println("<br/><br/>");

request.getRequestDispatcher("../footer.jsp").include(request, response);

out.flush();
out.close();

} 


catch (Throwable theException) 	    
{
System.out.println(theException); 
}
}
	
	
	
	
	
	
}
	
	
