package mainPackage;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

public class UpdateUserGet extends HttpServlet {

	/**
	 * Constructor of the object.
	 */
	public UpdateUserGet() {
		super();
	}

	/**
	 * Destruction of the servlet. <br>
	 */
	public void destroy() {
		super.destroy(); // Just puts "destroy" string in log
		// Put your code here
	}


public void doGet(HttpServletRequest request, HttpServletResponse response) 
			           throws ServletException, java.io.IOException {

try
{	    

          HttpSession session = request.getSession(true);	

          session.setAttribute("firstname", request.getParameter("firstname"));
          session.setAttribute("lastname", request.getParameter("lastname"));
          session.setAttribute("username", request.getParameter("username"));
          session.setAttribute("password", request.getParameter("password"));
          session.setAttribute("email", request.getParameter("email"));
          session.setAttribute("phone", request.getParameter("phone"));
          
          
          response.sendRedirect("updateuser.jsp"); //logged-in page      		
} 
		
		
catch (Throwable theException) 	    
{
     System.out.println(theException); 
}
       }


	public void init() throws ServletException {
		// Put your code here
	}

}
