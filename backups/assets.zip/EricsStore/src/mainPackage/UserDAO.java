package mainPackage;

import java.text.*;
import java.util.*;
import java.sql.*;

public class UserDAO 	
{
   static Connection currentCon = null;
   static ResultSet rs = null;  
	
   public static void closeQuietly(AutoCloseable ... closeables) {
	    for (AutoCloseable c : closeables) {
	        if (c != null) {
	            try {
	                c.close();
	            } catch (Exception e) {
	                // log or ignore, we can't do anything about it really
	            }
	        }
	    }
	}
   
	
   public static UserBean login(UserBean bean) {
	
      //preparing some objects for connection 
      Statement stmt = null;    
	
      String username = bean.getUsername();    
      String password = bean.getPassword();   
	    
      String searchQuery =
            "select * from users where username='"
                     + username
                     + "' AND password='"
                     + password
                     + "'";
	    
   try 
   {
      //connect to DB 
      currentCon = new ConnectionManager().connect();
      stmt=currentCon.createStatement();
      rs = stmt.executeQuery(searchQuery);	        
      boolean more = rs.next();
	       
      // if user does not exist set the isValid variable to false
      if (!more) 
      {
         System.out.println("Sorry, you are not a registered user! Please sign up first");
         bean.setValid(false);
      } 
	        
      //if user exists set the isValid variable to true
      else if (more) 
      {

         bean.setFirstName( rs.getString("FirstName") );
         bean.setLastName( rs.getString("LastName") );
         bean.setUsername( rs.getString("username") );
         bean.setEmail( rs.getString("email") );
         bean.setPhone( rs.getString("phone") );
         bean.setValid(true);
      }
   } 

   catch (Exception ex) 
   {
      System.out.println("Log In failed: An Exception has occurred! " + ex);
   } 
	    
   //some exception handling
   finally 
   {
	   closeQuietly(stmt, currentCon);
   }

return bean;
	
   }
   
   
   public static UserBean addUser(UserBean bean) {
    
	      String Query =
	            "insert into users (FirstName, LastName, username, password, email, phone)"
	                     + " values (?,?,?,?,?,?)"; 
	   try 
	   {
	      //connect to DB 
		   currentCon = new ConnectionManager().connect();
		   
		   PreparedStatement preparedStmt = currentCon.prepareStatement(Query);
	   
			preparedStmt.setString(1, bean.getFirstName() );
			preparedStmt.setString(2, bean.getLastName() );
			preparedStmt.setString(3, bean.getUsername() );
			preparedStmt.setString(4, bean.getPassword() );
			preparedStmt.setString(5, bean.getEmail() );
			preparedStmt.setString(6, bean.getPhone() );

		      boolean result = preparedStmt.execute();

	      if (result) 
	      {
	         System.out.println("New User Created!");
	         bean.setValid(false);
	      } 
	      
	      else 
	      {
	    	  System.out.println("No Result");
		         bean.setValid(true);
	      }

	   } 

	   catch (Exception ex) 
	   {
	      System.out.println("Duplicate Entry" + ex);
	   } 
		    

	   finally 
	   {
		   closeQuietly(currentCon);
	   }

	return bean;
		
	   }

   
   
   public static UserBean AdminAddUser(UserBean bean) {
	    
	      String Query =
	            "insert into users (FirstName, LastName, username, password, email, phone)"
	                     + " values (?,?,?,?,?,?)"; 
	   try 
	   {
	      //connect to DB 
		   currentCon = new ConnectionManager().connect();
		   
		   PreparedStatement preparedStmt = currentCon.prepareStatement(Query);
	   
			preparedStmt.setString(1, bean.getFirstName() );
			preparedStmt.setString(2, bean.getLastName() );
			preparedStmt.setString(3, bean.getUsername() );
			preparedStmt.setString(4, bean.getPassword() );
			preparedStmt.setString(5, bean.getEmail() );
			preparedStmt.setString(6, bean.getPhone() );

		      boolean result = preparedStmt.execute();

	      if (result) 
	      {
	         System.out.println("New User Created!");
	         //bean.setValid(false);
	      } 
	      
	      else 
	      {
	    	  System.out.println("No Result");
		       //  bean.setValid(true);
	      }

	   } 

	   catch (Exception ex) 
	   {
	      System.out.println("Duplicate Entry" + ex);
	   } 
		    

	   finally 
	   {
		   closeQuietly(currentCon);
	   }

	return bean;
		
	   }   

   
   public static List<UserBean> showAll() {
		
	   List<UserBean> userBeanList = new ArrayList<UserBean>();
	      String Query = "SELECT * FROM users"; 

	   System.out.println("Query: "+Query);
   
	   try 
	   {
	      //connect to DB 
		   currentCon = new ConnectionManager().connect();
		   
		Statement stmt   = currentCon.createStatement();
		   ResultSet rs = stmt.executeQuery(Query);
	       UserBean userBean = null;
		   while (rs.next())
		      {
			    userBean = new UserBean();
		        userBean.setUserID(rs.getInt("userID"));
		        userBean.setFirstName(rs.getString("FirstName"));
		        userBean.setLastName(rs.getString("LastName"));
		        userBean.setUsername(rs.getString("username"));
		        userBean.setPassword(rs.getString("password"));
		        userBean.setEmail(rs.getString("email"));
		        userBean.setPhone(rs.getString("phone"));
		       
		        userBeanList.add(userBean);
		      }
		  stmt.close();
	   }

	   catch (Exception ex) 
	   {
	      System.out.println("Log In failed: An Exception has occurred! " + ex);
	   } 

	   finally 
	   {
		   closeQuietly(rs, currentCon);
	   }

return userBeanList;
		
	   }   
   
// update user
	public static UserBean updateUser(UserBean bean) {

		Statement stmt = null;
		String Query = "UPDATE users SET FirstName = ?, LastName = ?, password = ?, email = ?, phone = ? WHERE username = ?";

		System.out.println("Query: " + Query);

		try {
			// connect to DB
			currentCon = new ConnectionManager().connect();

			PreparedStatement preparedStmt = currentCon.prepareStatement(Query);
			preparedStmt.setString(1, bean.getFirstName() );
			preparedStmt.setString(2, bean.getLastName() );
			preparedStmt.setString(3, bean.getPassword() );
			preparedStmt.setString(4, bean.getEmail() );
			preparedStmt.setString(5, bean.getPhone() );
			preparedStmt.setString(6, bean.getUsername() );

			boolean result = preparedStmt.execute();

			if (result) {
				System.out.println("Congratulations, User Updated");

			}

			if (!result) {
				 System.out.println("OOPS! We hit an issue!");
			}

		}

		catch (Exception ex) {
			System.out.println(ex);

		}

		// some exception handling
		finally {
			closeQuietly(stmt, rs, currentCon);
		}

		return bean;
	}
   

}
