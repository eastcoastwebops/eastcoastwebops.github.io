package mainPackage;
import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 * Servlet implementation class LoginServlet
 */
public class RegistrationServlet extends HttpServlet {


public void doPost(HttpServletRequest request, HttpServletResponse response) 
			           throws ServletException, java.io.IOException {

try
{	    
     UserBean user = new UserBean();
     
     user.setUsername(request.getParameter("username"));
     user.setPassword(request.getParameter("password"));
     user.setFirstName(request.getParameter("FirstName"));
     user.setLastName(request.getParameter("LastName"));
     user.setEmail(request.getParameter("email"));
     user.setPhone(request.getParameter("phone"));

     user = UserDAO.addUser(user);
	   
     System.out.println ("creating new user");
     
     HttpSession session = request.getSession(true);	
     session.setAttribute("UserBean", user);
     
     session.getAttribute("UserBean");
     if ( user.isValid() ){
    		 response.sendRedirect("/EricsStore/registrationsuccess.jsp"); // Pre Login page 
     }
     
     else {
    	 response.sendRedirect("/EricsStore/registrationerror.jsp"); // Pre Login page 
     
     }
     
} 
		
		
catch (Throwable theException) 	    
{
     System.out.println(theException); 
}
       }
	}
