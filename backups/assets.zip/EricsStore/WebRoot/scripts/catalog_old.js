 function page(data) {
    var arr = data;
    var index = 0;
    displayNext();
    $("#next").click(function() {
      displayNext();
    });

    function displayNext() {
      var list = $('#show-data');
      $('#show-data').empty();
    //  alert(data.length);
      var index = list.data('index') % arr.length || 0;
      alert (index);
      list.data('index', index + 9);
      list.html($.map(arr.slice(index, index + 9), function(element) {
        return "<div class=\"product\" style=\"display:none;\"><div class=\"productid\"><b>id #" + element.productid + "</b></div><div class=\"productname\"><b>" + element.productname + "</b></div><div class=\"sku\">Sku: <b>" + element.productsku + "</b></div><div class=\"price\"><b>$" + element.productprice + "</b></div>";
        $(resObject).appendTo("#show-data")
    }));
      
      x = 1;
      $(".product").each(function() {
        x++;
        $(this).delay(100 * x).fadeIn(500);
      });
    }    
 }


  window.URLtype = "http://localhost"; 
  function baseData() {
    $.ajax({
      url: URLtype + ':8080/ProductCatalog/product/basedata',
      type: 'POST',
      data: '',
      success: function() {
        $('#messages').hide().text("Add Random Products").fadeIn(600);
        showAll();
      }
    });
  };
  

  function SortByName(y, x) {
    return ((y.productname == x.productname) ? 0 : ((y.productname > x.productname) ? 1 : -1));
  }

  function SortByPrice(y, x) {
    return y.productprice - x.productprice;
  }
  
  function SortByID(y, x) {
	    return y.productid - x.productid;
	  }
  
function uppercase(str)
{
  var array1 = str.split(' ');
  var newarray1 = [];
    
  for(var x = 0; x < array1.length; x++){
      newarray1.push(array1[x].charAt(0).toUpperCase()+array1[x].slice(1));
  }
  return newarray1.join(' ');
}
  
  // Show All -------------------------------------------------------------	
  function showAll() {
    var resObject = "";
    $('#show-data').empty();
    var url = URLtype + ':8080/ProductCatalog/product/getAll';
    $.ajax({
      type: 'GET',
      url: url,
      data: {
        get_param: 'value'
      },
      dataType: 'json',
      success: function(data) {
    	  page(data);

      }
    });
  };
  
// Render -------------------------------------------------------------	
  function Render(data) {
    $.each(data, function(index, element) {
      resObject = "<div class=\"product\" style=\"display:none;\"><div class=\"productid\"><b>id #" + element.productid + "</b></div><div class=\"productname\"><b>" + element.productname + "</b></div><div class=\"sku\">Sku: <b>" + element.productsku + "</b></div><div class=\"price\"><b>$" + element.productprice + "</b></div>";
      $(resObject).appendTo("#show-data")
      x = 1;
      $(".product").each(function() {
        x++;
        $(this).delay(100 * x).fadeIn(500);
               
      });
    });
  }
  
  
  
  $(document).ready(function() {
   showAll();
   
  
	  
// RESET DATA ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    $(".resetdata").on('click', function() {
      baseData();
      
    });
    
 // add product 
    
    $(".addname").click(function() {
      productname = prompt("Product Name");
      productname = uppercase(productname);
      productsku = prompt("Product SKU");
      productsku = parseInt(productsku);
      productprice = prompt("Price");
      productprice = parseInt(productprice);
      buildurl = URLtype + ':8080/ProductCatalog/product/add/';
      buildurl += productname + "/" + productsku + "/" + productprice;
      $.ajax({
        url: buildurl,
        type: 'POST',
        data: '', // or $('#myform').serializeArray()
        success: function() {
          $('#messages').hide().text("New Product Added").fadeIn(1000);
        }
      });
      showAll();
    });
	
	
//  GetAll ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~				
    $(".getall").on('click', function() {
      showAll();
      
     
    });
	
	
//  Sort By name ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~				
    $(".sortbyname").on('click', function() {
    var resObject = "";
    $('#show-data').empty();
    var url = URLtype + ':8080/ProductCatalog/product/getAll';
    $.ajax({
      type: 'GET',
      url: url,
      data: {
        get_param: 'value'
      },
      dataType: 'json',
      success: function(data) {
       data.sort(SortByName);
      //  page(data.sort(SortByName));

      }
    });

	  
    });	
    
    
    
    //  Sort By Price ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~				
    $(".sortbyprice").on('click', function() {
    var resObject = "";
    $('#show-data').empty();
    var url = URLtype + ':8080/ProductCatalog/product/getAll';
    $.ajax({
      type: 'GET',
      url: url,
      data: {
        get_param: 'value'
      },
      dataType: 'json',
      success: function(data) {
        data.sort(SortByPrice);
        page(data);
     //   quickRender(data);
      }
    });

	  
    });	
	

 //  Delete ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~	
    $(".remove").click(function() {
      productsku = prompt("Product SKU to remove");
      productsku = parseInt(productsku);
      buildurl = URLtype + ':8080/ProductCatalog/product/delete/';
      buildurl += productsku;
      $.ajax({
        url: buildurl,
        type: 'POST',
        data: '', // or $('#myform').serializeArray()
        success: function() {
          $('#messages').hide().text("Product Deleted").delay(2000).fadeIn(1000);
           showAll();
        }
      });
     
      Render(data).delay(1000).location.reload();
    });
 
 
//  Delete by click ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~	 
       $("#show-data").on('click', '.productid',function() {
     
    	 var productsku = $(this).siblings('.sku').text();
    	 var productname = $(this).siblings('.productname').text();
    	 var productid = $(this).text();
      
     	productsku = productsku.split("Sku: ").pop()
    	
	alert ("deleting prod ID: " + productid + ", \"" + productname + "\", SKU:" + productsku);
    productsku = parseInt(productsku);
    
       buildurl = URLtype + ':8080/ProductCatalog/product/delete/';
      buildurl += productsku;
      
      $.ajax({
        url: buildurl,
        type: 'POST',
        data: '', // or $('#myform').serializeArray()
        success: function() {
          $('#messages').hide().text("Product Removed").fadeIn(1000);
          showAll();
        }
      });
      
      Render(data).delay(10000).location.reload(); 
    });
    
    
 //  Rename by click ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~	 
       $("#show-data").on('click', '.productname',function() {
     
    	 var productsku = $(this).siblings('.sku').text();
    	 var productname = $(this).siblings('.productname').text();
    	 var productid = $(this).siblings('.productid').text();
    	 var productprice = $(this).siblings('.price').text();
      	
     	productid = productid.split("id #").pop();
     	productprice = productprice.split("$").pop();
		productname = prompt("New Name",productname);
		productprice = prompt("Price",productprice);
    	//productprice = parseInt(productprice);
      buildurl = URLtype + ':8080/ProductCatalog/product/rename/';
      buildurl += productname + "/" + productid + "/" + productprice;
   
      $.ajax({
        url: buildurl,
        type: 'POST',
        data: '', // or $('#myform').serializeArray()
        success: function() {
          $('#messages').hide().text("Product updated").fadeIn(1000);
          $('#show-data').empty();
          showAll();
          Render(data).delay(100).location.reload(); 
        }
      });
      
    //  Render(data).delay(10000).location.reload(); 
    });       
   
   
    
//  Filter By PRicek ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~	 
       $(".pricerange").click(function() {
		pricerangelow = prompt("Minimum price");
		pricerangehigh = prompt("Maximum price");
    	pricerangelow = parseInt(pricerangelow);
    	pricerangehigh = parseInt(pricerangehigh);
    	
    	
      buildurl = URLtype + ':8080/ProductCatalog/product/range/';
      buildurl += pricerangelow + "/" + pricerangehigh;
   alert (buildurl);
    $.ajax({
      type: 'GET',
      url: buildurl,
      data: {
        get_param: 'value'
      },
      dataType: 'json',
      success: function(data) {
       $('#show-data').empty();
          $.each(data, function(index, element) {
      resObject = "<div class=\"product\" style=\"display:none;\"><div class=\"productid\"><b>id #" + element.productid + "</b></div><div class=\"productname\"><b>" + element.productname + "</b></div><div class=\"sku\">Sku: <b>" + element.productsku + "</b></div><div class=\"price\"><b>$" + element.productprice + "</b></div>";
      $(resObject).appendTo("#show-data")
      x = 1;
      $(".product").each(function() {
        x++;
        $(this).delay(100 * x).fadeIn(500);

        
      });
    });
      
      }
    });
    });       
   
	
// DELETE ALL ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~		
    $(".removeall").click(function() {
      buildurl = URLtype + ':8080/ProductCatalog/product/deleteAll';
      //buildurl += id;
      $.ajax({
        url: buildurl,
        type: 'POST',
        data: '', // or $('#myform').serializeArray()
        success: function() {
          $('#messages').hide().text("All Products Deleted!!").fadeIn(1000);
        }
      });
      showAll();
    });
    
    
 

    
    // End  ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~					
  });
  
  
  
  /**
 * 
 */