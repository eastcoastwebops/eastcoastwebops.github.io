





///  interface

public interface Order {
	public void execute();
	}
	
public Class BuyStock implements Order {
	public stock;  // could be private
	
	public void BuyStock (Stock stock) {

		this.stock = stock;
		}
	
	public void execute () {
		stock.buy();
		}
	}
	
	
public Class SellStock implements Order {
	public stock;
	
	public void SellStock (Stock stock) {    // constructor

		this.stock = stock;
		}
		
	public void execute () {
		stock.sell();
		}
	}

	
	
	public class Stock {
		public string name;
		public int amount;
		
		public void buy() {
		DO SOMEATHING
		out.buy ("yuah");
		}
		
		
		public void sell() {
		sys.out....
		}
	}
		
		
// new class  Broker

public void Broker {
	
	private Order order;
	list<Order> orders = new ArrayList<Order>();
	
	public void takeOrder(Order order)  {
	orders.add(order);
	}
	
	public void placeOrders()
	{
	for (int = 0; i < orders.size(); i++)
	Order order = orders(i);
	order.execute();
	}
}



// command
public class CommandPatternDemo {
	public static void main (String[] args ) {
		Stock abdStock = new Stock ();
		
		BuyStock buyStockOrder = new BuyStock(abcstock);
		SellStock sellStockOrder = new SellStock(abcstock);
		
		Broker broker = new Broker ();
		broker.takeOrder(buyStockOrder);
		broker,takeOrder(sellStockOrder);
		
		broker.placeOrders();
		
	}		
}