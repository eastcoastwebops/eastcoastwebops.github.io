package dataPackage;

import java.text.*;
import java.util.*;
import java.sql.*;

import javax.ws.rs.PathParam;

public class ProductDAO {
	static Connection currentCon = null;
	static ResultSet rs = null;

	public static ProductBean addProduct(ProductBean bean) {
		// preparing some objects for connection
		Statement stmt = null;
		String ProductName = bean.getProductname();
		int ProductSKU = bean.getProductsku();
		int ProductPrice = bean.getProductprice();

		String Query = "insert into product_table (ProductName, ProductSKU, ProductPrice)"
				+ " values (?,?,?)";

		System.out.println("Query: " + Query);

		try {
			// connect to DB
			currentCon = new ProductConnectionManager().connect();

			PreparedStatement preparedStmt = currentCon.prepareStatement(Query);
			preparedStmt.setString(1, ProductName);
			preparedStmt.setInt(2, ProductSKU);
			preparedStmt.setInt(3, ProductPrice);

			boolean result = preparedStmt.execute();

			if (result) {
				System.out.println("Congratulations, Product Added!");

			}

			if (!result) {
				// System.out.println("OOPS! Product Was Not Added!");
			}

		}

		catch (Exception ex) {
			System.out.println(ex);

		}

		// some exception handling
		finally {
			if (rs != null) {
				try {
					rs.close();
				} catch (Exception e) {
				}
				rs = null;
			}

			if (stmt != null) {
				try {
					stmt.close();
				} catch (Exception e) {
				}
				stmt = null;
			}

			if (currentCon != null) {
				try {
					currentCon.close();
				} catch (Exception e) {
				}

				currentCon = null;
			}
		}

		return bean;

	}

	// ///

	public static List<ProductBean> showAll() {

		List<ProductBean> productBeanList = new ArrayList<ProductBean>();
		Statement stmt = null;
		String Query =
		// "SELECT * FROM product_table";
		"SELECT * FROM product_table ORDER BY productID ASC";
		System.out.println("Query: " + Query);

		try {
			// connect to DB
			currentCon = new ProductConnectionManager().connect();

			Statement st = currentCon.createStatement();
			ResultSet rs = st.executeQuery(Query);
			ProductBean productBean = null;
			while (rs.next()) {
				productBean = new ProductBean();
				productBean.setProductid(rs.getInt("productID"));
				productBean.setProductname(rs.getString("productName"));
				productBean.setProductsku(rs.getInt("productSKU"));
				productBean.setProductprice(rs.getInt("productPrice"));
				productBeanList.add(productBean);
			}

			st.close();
		}

		catch (Exception ex) {
			System.out.println("Potential Error" + ex);
		} finally {
			if (rs != null) {
				try {
					rs.close();
				} catch (Exception e) {
				}
				rs = null;
			}

			if (stmt != null) {
				try {
					stmt.close();
				} catch (Exception e) {
				}
				stmt = null;
			}

			if (currentCon != null) {
				try {
					currentCon.close();
				} catch (Exception e) {
				}

				currentCon = null;
			}
		}

		return productBeanList;

	}

	/* end product show all */

	public static ProductBean deleteProduct(ProductBean bean) {
		// preparing some objects for connection
		Statement stmt = null;
		int ProductSKU = bean.getProductsku();

		String Query = "Delete FROM product_table where productsku = ?";

		System.out.println("Query: " + Query);

		try {
			// connect to DB
			currentCon = new ProductConnectionManager().connect();

			PreparedStatement preparedStmt = currentCon.prepareStatement(Query);
			preparedStmt.setInt(1, ProductSKU);

			boolean result = preparedStmt.execute();

			if (result) {
				System.out.println("Product Deleted)");
			}

		}

		catch (Exception ex) {
			System.out
					.println("Product delete Failed An Exception has occurred! "
							+ ex);
		}

		// some exception handling
		finally {
			if (rs != null) {
				try {
					rs.close();
				} catch (Exception e) {
				}
				rs = null;
			}

			if (stmt != null) {
				try {
					stmt.close();
				} catch (Exception e) {
				}
				stmt = null;
			}

			if (currentCon != null) {
				try {
					currentCon.close();
				} catch (Exception e) {
				}

				currentCon = null;
			}
		}

		return bean;

	}

	/* end product show all */

	public static void deleteAllProducts() {
		// preparing some objects for connection
		Statement stmt = null;

		String Query = "Delete FROM product_table";

		System.out.println("Query: " + Query);

		try {
			// connect to DB
			currentCon = new ProductConnectionManager().connect();

			PreparedStatement preparedStmt = currentCon.prepareStatement(Query);
			// preparedStmt.setInt (1, ProductSKU);

			boolean result = preparedStmt.execute();

			if (result) {
				System.out.println("Product Deleted)");
			}

		}

		catch (Exception ex) {
			System.out
					.println("Product delete Failed An Exception has occurred! "
							+ ex);
		}

		// some exception handling
		finally {
			if (rs != null) {
				try {
					rs.close();
				} catch (Exception e) {
				}
				rs = null;
			}

			if (stmt != null) {
				try {
					stmt.close();
				} catch (Exception e) {
				}
				stmt = null;
			}

			if (currentCon != null) {
				try {
					currentCon.close();
				} catch (Exception e) {
				}

				currentCon = null;
			}
		}

		// return;

	}

	public static ProductBean renameProduct(ProductBean bean) {
		// preparing some objects for connection
		Statement stmt = null;
		String ProductName = bean.getProductname();
		int ProductID = bean.getProductid();
		int ProductPrice = bean.getProductprice();

		String Query = "UPDATE product_table SET productName = ?, productPrice = ? WHERE productID = ?";

		System.out.println("Query: " + Query);

		try {
			// connect to DB
			currentCon = new ProductConnectionManager().connect();

			PreparedStatement preparedStmt = currentCon.prepareStatement(Query);
			preparedStmt.setString(1, ProductName);
			preparedStmt.setInt(2, ProductPrice);
			preparedStmt.setInt(3, ProductID);

			boolean result = preparedStmt.execute();

			if (result) {
				System.out.println("Congratulations, Product Renamed");

			}

			if (!result) {
				// System.out.println("OOPS! Product Was Not Added!");
			}

		}

		catch (Exception ex) {
			System.out.println(ex);

		}

		// some exception handling
		finally {
			if (rs != null) {
				try {
					rs.close();
				} catch (Exception e) {
				}
				rs = null;
			}

			if (stmt != null) {
				try {
					stmt.close();
				} catch (Exception e) {
				}
				stmt = null;
			}

			if (currentCon != null) {
				try {
					currentCon.close();
				} catch (Exception e) {
				}

				currentCon = null;
			}
		}

		return bean;

	}

	// Gen 3 - swapped out productbean.range with new PriceRange object
	public static List<ProductBean> pricerange(PriceRange range) {

		List<ProductBean> productBeanList = new ArrayList<ProductBean>();
		Statement stmt = null;

		int pricelow = range.getPricerangelow();
		int pricehigh = range.getPricerangehigh();

		String Query = "SELECT * FROM product_table WHERE productPrice >= '"
				+ pricelow + "' and productPrice <= '" + pricehigh + "'";
		System.out.println("Query: " + Query);

		try {
			// connect to DB
			currentCon = new ProductConnectionManager().connect();

			PreparedStatement preparedStmt = currentCon.prepareStatement(Query);
			// preparedStmt.setInt (1, pricelow);
			// preparedStmt.setInt (2, pricehigh);

			// Statement st = currentCon.createStatement();
			ResultSet rs = preparedStmt.executeQuery(Query);
			ProductBean productBean = null;
			while (rs.next()) {
				productBean = new ProductBean();
				productBean.setProductid(rs.getInt("productID"));
				productBean.setProductname(rs.getString("productName"));
				productBean.setProductsku(rs.getInt("productSKU"));
				productBean.setProductprice(rs.getInt("productPrice"));
				productBeanList.add(productBean);
			}

			preparedStmt.close();
		}

		catch (Exception ex) {
			System.out.println("Potential Error" + ex);
		} finally {
			if (rs != null) {
				try {
					rs.close();
				} catch (Exception e) {
				}
				rs = null;
			}

			if (stmt != null) {
				try {
					stmt.close();
				} catch (Exception e) {
				}
				stmt = null;
			}

			if (currentCon != null) {
				try {
					currentCon.close();
				} catch (Exception e) {
				}

				currentCon = null;
			}
		}

		return productBeanList;

	}

	// ///

}
