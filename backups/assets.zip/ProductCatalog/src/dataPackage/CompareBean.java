package dataPackage;

import java.util.Comparator;

public class CompareBean implements Comparator<ProductBean>{

	@Override
	public int compare(ProductBean o1, ProductBean o2) {
		// TODO Auto-generated method stub
		return o1.getProductprice() - o2.getProductprice();
	}

}
