package dataPackage;

public class PriceRange {
	
    private int pricerangelow;
    private int pricerangehigh;
	public int getPricerangelow() {
		return pricerangelow;
	}
	public void setPricerangelow(int pricerangelow) {
		this.pricerangelow = pricerangelow;
	}
	public int getPricerangehigh() {
		return pricerangehigh;
	}
	public void setPricerangehigh(int pricerangehigh) {
		this.pricerangehigh = pricerangehigh;
	}
    

}
