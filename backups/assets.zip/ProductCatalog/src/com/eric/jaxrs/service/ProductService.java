package com.eric.jaxrs.service;

import javax.ws.rs.core.Response;

import com.eric.jaxrs.model.Product;

public interface ProductService {

	public Response addProduct();
	
	public Response deleteProduct(int id);
	
	public Product getProduct(int id); // not really used yet
	
	public Response getAllProducts();
	
	public Response deleteAllProducts();
	
	public Response addProduct(String productname, int productprice,int productsku);

	public Response renameProduct(String productname, int productid, int productprice);

	public Response rangeProduct(int pricerangelow, int pricerangehigh);

	public Response addFromFile();

	




}
