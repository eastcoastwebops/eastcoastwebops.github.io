package com.eric.jaxrs.service;


import java.io.PrintWriter;
import java.net.URISyntaxException;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.Set;
import java.util.SortedMap;
import java.util.TreeMap;

import javax.ws.rs.Consumes;
import javax.ws.rs.DELETE;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.WebApplicationException;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import com.eric.jaxrs.model.Product;
import com.eric.jaxrs.model.GenericResponse;

import dataPackage.CompareBean;
import dataPackage.PriceRange;
import dataPackage.ProductBean;
import dataPackage.ProductDAO;
import fileProcess.FileProcessAddProducts;

@Path("/product")

/*@Consumes(MediaType.APPLICATION_XML)
@Produces(MediaType.APPLICATION_XML)*/

@Consumes(MediaType.APPLICATION_JSON)
@Produces(MediaType.APPLICATION_JSON)
public class ProductServiceImpl<Reponse> implements ProductService {

	private static SortedMap<Integer,Product> emps = new TreeMap<Integer,Product>();
	
	@Override
	@POST
    @Path("/basedata")
	public Response addProduct() {

		//Populate Database with 4 random items/prices each time this is called
		
	     ProductBean product = new ProductBean();
	     String type = "Ice Cream:Chicken Sandwich:Tuna Sandwich:Chair:Pillow:Computer:Phone:Scarf:Socks:Shoes:Jacket:Sneakers:Gloves:Hat:Bottled Water:Bracelet:Candy Bar:Milk";
	     String[] wordsAsArray = type.split(":");
	    
	     for (int num = 0; num < 4; num++) {
	     int i = (int) new Date().getTime();
	     int index = new Random().nextInt(wordsAsArray.length);
	     String randomClothes = wordsAsArray[index];
	     Random r = new Random();
	     int Low = 10;
	     int High = 1000;
	     int Result = r.nextInt(High-Low) + Low;

	     product.setProductname(randomClothes);
	     product.setProductsku(i);
	     product.setProductprice(Result);
	     product = ProductDAO.addProduct(product);
	     }
	     
		GenericResponse response = new GenericResponse();
		return Response.ok(response).header("Access-Control-Allow-Origin", "*").build();
	}
	

	@Override
	@POST
    @Path("add/{productname}/{productsku}/{productprice}")
	public Response addProduct(@PathParam("productname") String productname, @PathParam("productprice") int productprice, @PathParam("productsku") int productsku) {

	     ProductBean product = new ProductBean();
	    
	     product.setProductname(productname);
	     product.setProductsku(productsku);
	     product.setProductprice(productprice);
	     product = ProductDAO.addProduct(product);
		   
	     System.out.println ("creating new product ");

	     int valid = product.getProductid();
		GenericResponse response = new GenericResponse();
		
		response.setStatus(true);
		
		if (valid != 0) {
		response.setMessage("Product " + productsku + " with name of "+productname+" with price of "+productprice+" was created successfully");
		
		System.out.println(".........................................   ");
		System.out.println("Product " + productsku + " with name of "+productname+" with price of "+productprice+" was created successfully");
		System.out.println(".........................................   ");
		return Response.ok(response).header("Access-Control-Allow-Origin", "*").build();
		}
		else {
			System.out.println("Error Creating Product");
			response.setMessage("Error");
			return Response.ok(response).header("Access-Control-Allow-Origin", "*").build();

		}
	}
	


	@Override
	@POST
    @Path("delete/{productsku}")
	public Response deleteProduct(@PathParam("productsku") int productsku) {
		
		ProductBean product = new ProductBean();
	     product.setProductsku(productsku);
	     product = ProductDAO.deleteProduct(product);
	     System.out.println ("deleting product ");
		
		
		
		GenericResponse response = new GenericResponse();
		if(product == null){
			response.setStatus(false);
			response.setMessage("Product Doesn't Exists");
			response.setErrorCode("EC-02");
			return Response.status(404).entity(response).header("Access-Control-Allow-Origin", "*").build();
		}
		
		System.out.println(".........................................   ");
		System.out.println(" Deleted " +  product.getProductsku() );
		System.out.println(".........................................   ");
		
		response.setStatus(true);
		response.setMessage("Product deleted successfully");
		//System.out.println("Products Deleted " + id);
		
		return Response.ok(response).header("Access-Control-Allow-Origin", "*").build();
		
	}
	
	
	
	
	@Override
	@POST
	@Path("/deleteAll")
	public Response deleteAllProducts() {
		GenericResponse response = new GenericResponse();

	
	    
	     ProductDAO.deleteAllProducts();
	     System.out.println ("deleting ALL product ");
		
		
		    System.out.println("");
			System.out.println("------------------------------");
			System.out.println("All Products Deleted by Client");
			System.out.println("------------------------------");
		//	emps.remove(id);
			
		
		response.setMessage("Product deleted successfully");
		return Response.ok(response).header("Access-Control-Allow-Origin", "*").build();
	}
	
	

	@Override
	@GET
	@Path("/{id}/get")
	public Product getProduct(@PathParam("id") int id) {
		return emps.get(id);
		
	}
	

	@Override
	@GET
	@Path("/getAll")
	public Response getAllProducts() {
		List<ProductBean> productList = ProductDAO.showAll();
	//	Collections.sort(productList, new CompareBean());
		System.out.println("Get All Products Requested From Client");
		return Response.ok(productList).header("Access-Control-Allow-Origin", "*").build();
	}
	

	
	@Override
	@POST
    @Path("rename/{productname}/{productid}/{productprice}")
	public Response renameProduct(@PathParam("productname") String productname, @PathParam("productid") int productid, @PathParam("productprice") int productprice) {

	     ProductBean product = new ProductBean();

	     product.setProductname(productname);
	     product.setProductid(productid);
	     product.setProductprice(productprice);
	     product = ProductDAO.renameProduct(product);
		   
	     System.out.println ("Rename new product ");

	     int valid = product.getProductid();
		GenericResponse response = new GenericResponse();
		
		response.setStatus(true);
		
		if (valid != 0) {
		return Response.ok(response).header("Access-Control-Allow-Origin", "*").build();
		}
		else {
		return Response.ok(response).header("Access-Control-Allow-Origin", "*").build();

		}
	}
	
	
	@Override
	@GET
    @Path("range/{pricerangelow}/{pricerangehigh}")
	public Response rangeProduct(@PathParam("pricerangelow") int pricerangelow, @PathParam("pricerangehigh") int pricerangehigh) {

	     PriceRange range = new PriceRange(); 
	     range.setPricerangelow(pricerangelow);
	     range.setPricerangehigh(pricerangehigh);
	     
	     List<ProductBean> productList = ProductDAO.pricerange(range);
		//Collections.sort(productList, new CompareBean());
		System.out.println("Get All Products Requested From Client");
		return Response.ok(productList).header("Access-Control-Allow-Origin", "*").build();
	}
	
	
	@Override
	@POST
    @Path("/productsfromfile")
	public Response addFromFile() {

		//Populate Database with 4 random items/prices each time this is called
		
		FileProcessAddProducts process = new FileProcessAddProducts();
		process.main(null);
	     
		GenericResponse response = new GenericResponse();
		return Response.ok(response).header("Access-Control-Allow-Origin", "*").build();

		//Populate Database with 4 random items/prices each time this is called
		
	    
	 
	}
	


	
}
