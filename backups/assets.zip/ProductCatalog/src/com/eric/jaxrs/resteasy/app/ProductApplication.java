package com.eric.jaxrs.resteasy.app;

import java.util.HashSet;
import java.util.Set;

import javax.ws.rs.core.Application;

import com.eric.jaxrs.service.ProductServiceImpl;

public class ProductApplication extends Application {
	
	private Set<Object> singletons = new HashSet<Object>();

	@SuppressWarnings("rawtypes")
	public ProductApplication() {
		singletons.add(new ProductServiceImpl());
	}

	@Override
	public Set<Object> getSingletons() {
		return singletons;
	}

}
