package com.eric.jaxrs.model;

import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement(name = "product")
public class Product {
	private String productname;
	private int productprice;
	private int productid;
	private int productsku;



	public String getProductname() {
		return productname;
	}



	public void setProductname(String productname) {
		this.productname = productname;
	}



	public int getProductprice() {
		return productprice;
	}



	public void setProductprice(int productprice) {
		this.productprice = productprice;
	}



	public int getProductid() {
		return productid;
	}



	public void setProductid(int productid) {
		this.productid = productid;
	}



	public int getProductsku() {
		return productsku;
	}



	public void setProductsku(int productsku) {
		this.productsku = productsku;
	}



	@Override
	public String toString() {
		return productsku + "::" + productname + "::" + productprice;
	}

}
