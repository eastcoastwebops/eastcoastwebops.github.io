package fileProcess;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;

import dataPackage.ProductBean;
import dataPackage.ProductDAO;
import dataPackage.CompareBean;

public class FileProcessAddProducts {
	
	    public static void main(String[] args) {
	    	
	    	  ProductBean product = new ProductBean();

	        String csvFile = "C:/EricsProductsInput/NewProducts.txt";
	        String line = "";
	        String SplitBy = "\\|";
	        int counti=0;
	        try (BufferedReader br = new BufferedReader(new FileReader(csvFile))) {
	        	
	            while ((line = br.readLine()) != null) {
	            	
	                // use pipe as separator
	                String[] newproduct = line.split(SplitBy);
	                System.out.println("Reading Product: Name --> " + 
	                newproduct[0] + " SKU --> " + newproduct[1] + " Price -->" + newproduct[2] );
	                counti++;
	                
	                product.setProductname( newproduct[0] );
	                product.setProductsku( Integer.parseInt(newproduct[1]) );
	                product.setProductprice( Integer.parseInt(newproduct[2]) );
	                product = ProductDAO.addProduct(product);
	                
	            }
	           

	        } catch (IOException e) {
	            e.printStackTrace();
	        }
	        System.out.println("Number Of Products Read: " + counti);
	    }

	}	
	
